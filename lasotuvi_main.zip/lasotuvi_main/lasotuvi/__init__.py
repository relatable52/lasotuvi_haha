#!/usr/bin/env python
# -*- coding: utf-8 -*-
__title__ = 'lasotuvi'
__version__ = '1.0.1'
__author__ = 'doanguyen'
__author_email__ = 'dungnv2410 at gmail.com'
__license__ = 'MIT License'
